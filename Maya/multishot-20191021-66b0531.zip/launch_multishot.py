import multishot
win = multishot.Window()
win.show()
